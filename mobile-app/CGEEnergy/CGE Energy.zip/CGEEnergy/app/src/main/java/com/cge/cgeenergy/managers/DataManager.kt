package com.cge.cgeenergy.managers

import com.cge.cgeenergy.models.Actual_response_date

object DataManager {

    var actualDateResponse: List<Actual_response_date> = arrayListOf()
}