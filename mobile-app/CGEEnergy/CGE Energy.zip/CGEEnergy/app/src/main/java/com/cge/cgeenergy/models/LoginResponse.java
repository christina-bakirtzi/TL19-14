package com.cge.cgeenergy.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

//TODO change when api ready
public class LoginResponse {

    @SerializedName("token")
    @Expose
    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

}