package com.cge.cgeenergy.interfaces

import com.cge.cgeenergy.models.*
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

//interface Api {
//
//    @GET("Login")
//    fun login(@Query("username") username: String, @Query("password") password: String): Call<List<LoginResponse>>
//
//
//}
//interface Api {
////
////    @POST("Login")
////    @FormUrlEncoded
////    fun login(@Field("username") username: String, @Field("password") password: String): Call<LoginResponse>
////}
interface Api {
    @POST("Login")
    fun login(@Header("Authorization") authorization: String): Call<LoginResponse>

    @GET("ActualTotalLoad/{areaName}/{resolution}/{datetype}/{date}")
    fun getactualtotalloadyear(@Path("areaName") areaName: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<Actual_response_year>>
    @GET("ActualTotalLoad/{areaName}/{resolution}/{datetype}/{date}")
    fun getactualtotalloadmonth(@Path("areaName") areaName: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<Actual_response_month>>
    @GET("ActualTotalLoad/{areaName}/{resolution}/{datetype}/{date}")
    fun getactualtotalloaddate(@Path("areaName") areaName: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<Actual_response_date>>

    @GET("AggregatedGenerationPerType/{areaName}/{productionType}|AllTypes/{resolution}/{datetype}/{date}")
    fun getaggregatedgenerationpertypeyear(@Path("areaName") areaName: String,@Path("productionType") productionType: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<Aggregated_response_year>>
    @GET("AggregatedGenerationPerType/{areaName}/{productionType}|AllTypes/{resolution}/{datetype}/{date}")
    fun getaggregatedgenerationpertypemonth(@Path("areaName") areaName: String,@Path("productionType") productionType: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<Aggregated_response_month>>
    @GET("AggregatedGenerationPerType/{areaName}/{productionType}|AllTypes/{resolution}/{datetype}/{date}")
    fun getaggregatedgenerationpertypedate(@Path("areaName") areaName: String,@Path("productionType") productionType: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<Aggregated_response_date>>

    @GET("DayAheadTotalLoadForecast/{areaName}/{resolution}/{datetype}/{date}")
    fun getdayaheadtotalloadyear(@Path("areaName") areaName: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<Day_response_year>>
    @GET("DayAheadTotalLoadForecast/{areaName}/{resolution}/{datetype}/{date}")
    fun getdayaheadtotalloadmonth(@Path("areaName") areaName: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<Day_response_month>>
    @GET("DayAheadTotalLoadForecast/{areaName}/{resolution}/{datetype}/{date}")
    fun getdayaheadtotalloaddate(@Path("areaName") areaName: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<Day_response_date>>

    @GET("DayAheadTotalLoadForecast/{areaName}/{resolution}/{datetype}/{date}")
    fun getavsftotalloadyear(@Path("areaName") areaName: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<AvsF_response_year>>
    @GET("DayAheadTotalLoadForecast/{areaName}/{resolution}/{datetype}/{date}")
    fun getavsftotalloadmonth(@Path("areaName") areaName: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<AvsF_response_month>>
    @GET("DayAheadTotalLoadForecast/{areaName}/{resolution}/{datetype}/{date}")
    fun getavsftotalloaddate(@Path("areaName") areaName: String, @Path("resolution") resolution: String,@Path("datetype") datetype: String, @Path("date") date: String):Call<List<AvsF_response_date>>

}
