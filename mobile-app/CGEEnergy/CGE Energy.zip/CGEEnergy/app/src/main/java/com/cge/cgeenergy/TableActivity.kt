package com.cge.cgeenergy

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.cge.cgeenergy.managers.DataManager


class TableActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_table)

        DataManager.actualDateResponse
    }
}

